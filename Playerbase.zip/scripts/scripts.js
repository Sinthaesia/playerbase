$('.content-slider').slick({
  dots: true,
  arrows: false,
  autoplay: true,
  autoplaySpeed: 5000,
});
